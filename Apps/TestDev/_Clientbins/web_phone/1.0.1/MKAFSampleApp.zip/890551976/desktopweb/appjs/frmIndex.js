define("frmIndex", function() {
    return function(controller) {
        function addWidgetsfrmIndex() {
            this.setDefaultUnit(voltmx.flex.DP);
            var Label0g0503887fc9a4c = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "Label0g0503887fc9a4c",
                "isVisible": true,
                "skin": "defLabel",
                "text": "Welcome to AF",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0bd8baf3e7c3a4b = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0bd8baf3e7c3a4b",
                "isVisible": true,
                "left": "541dp",
                "onClick": controller.AS_Button_ac59beae58e34520bb853877c4e4146d,
                "skin": "defBtnNormal",
                "text": "Take me Back",
                "top": "489dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(Label0g0503887fc9a4c, Button0bd8baf3e7c3a4b);
        };
        return [{
            "addWidgets": addWidgetsfrmIndex,
            "enabledForIdleTimeout": false,
            "id": "frmIndex",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "MKAFSampleApp"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});