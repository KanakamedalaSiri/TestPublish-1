define("userfrmIndexController", {
    //Type your controller code here 
});
define("frmIndexControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_ac59beae58e34520bb853877c4e4146d: function AS_Button_ac59beae58e34520bb853877c4e4146d(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("frmHome");
        ntf.navigate();
    }
});
define("frmIndexController", ["userfrmIndexController", "frmIndexControllerActions"], function() {
    var controller = require("userfrmIndexController");
    var controllerActions = ["frmIndexControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
