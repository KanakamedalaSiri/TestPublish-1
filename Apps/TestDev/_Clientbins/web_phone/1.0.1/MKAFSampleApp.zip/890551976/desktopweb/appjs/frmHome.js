define("frmHome", function() {
    return function(controller) {
        function addWidgetsfrmHome() {
            this.setDefaultUnit(voltmx.flex.DP);
            var Label0ge5e4ac4719049 = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "Label0ge5e4ac4719049",
                "isVisible": true,
                "skin": "defLabel",
                "text": "Hello Welcome to AF Sample App",
                "width": "60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0ge646db6b80349 = new voltmx.ui.Button({
                "centerX": "50%",
                "centerY": "60%",
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0ge646db6b80349",
                "isVisible": true,
                "left": "536dp",
                "onClick": controller.AS_Button_de6461fa3aa9445d9881f2c72a555c6a,
                "skin": "defBtnNormal",
                "text": "Click Me",
                "top": "508dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(Label0ge5e4ac4719049, Button0ge646db6b80349);
        };
        return [{
            "addWidgets": addWidgetsfrmHome,
            "enabledForIdleTimeout": false,
            "id": "frmHome",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "MKAFSampleApp"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});