define("userfrmHomeController", {
    //Type your controller code here 
});
define("frmHomeControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_de6461fa3aa9445d9881f2c72a555c6a: function AS_Button_de6461fa3aa9445d9881f2c72a555c6a(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("frmIndex");
        ntf.navigate();
    }
});
define("frmHomeController", ["userfrmHomeController", "frmHomeControllerActions"], function() {
    var controller = require("userfrmHomeController");
    var controllerActions = ["frmHomeControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
